/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.provap2;

/**
 *
 * @author bruno-fevereiro
 */
public class ProvaP2 {

    public static void main(String[] args) {
       }
}
